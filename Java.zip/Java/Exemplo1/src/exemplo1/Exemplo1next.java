package exemplo1;
import java.util.Scanner;
public class Exemplo1next {


 public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    
        System.out.println("Digite uma opção: ");
        System.out.println("1- SOMA\n 2-SUBTRAÇÃO \n3-MULTIPLICAÇÃO \n4-DIVISÃO \n 5-SAIR");
        
        
        
        System.out.println("Digite a primeira variavel: ");
         double n1= sc.nextDouble();
        System.out.println("Digite a segunda variavel: ");
        double n2= sc.nextDouble();
        int opc = sc.nextInt();
        switch(opc){
            case 1 -> {  
                System.out.println("você escolheu soma! ");
                
                
                double soma= n1+n2;
                System.out.println("A soma dos numeros é : " + soma);
         }
            
            default -> System.out.println("Opcão invalida ");    
}
 }}
