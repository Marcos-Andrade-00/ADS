package exemplo1;
import java.util.Scanner;

public class Exemplo1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite uma opção: ");
        System.out.println("1- SOMA\n 2-SUBTRAÇÃO \n3-MULTIPLICAÇÃO \n4-DIVISÃO \n 5-SAIR");
        int opc = sc.nextInt();
        System.out.println("Digite a primeira variavel: ");
         double n1= sc.nextDouble();
        System.out.println("Digite a segunda variavel: ");
        double n2= sc.nextDouble();
        switch(opc){
            case 1 -> {
                System.out.println("você escolheu soma! ");
                System.out.println("A soma é " + n1+n2);
            }
            case 2 -> {
                System.out.println("você escolheu subtração! ");
                System.out.println("A subtração é " + (n1-n2));}
            case 3 -> {
                System.out.println("você escolheu multiplicação! ");
                System.out.println("A multiplicação é " +n1*n2);}
            case 4 -> {
                System.out.println("você escolheu divisão! ");
                System.out.println("A divisão é " + n1/n2);}
            case 5 -> {
                System.out.println("opção invalida! ");}
                
            default -> System.out.println("Opcão invalida ");
        }
    }
    
}
