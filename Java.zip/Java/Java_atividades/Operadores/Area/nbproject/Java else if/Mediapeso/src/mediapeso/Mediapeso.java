
package mediapeso;
import java.util.Scanner;
public class Mediapeso {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double imc;
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite o seu peso");
        double peso = sc.nextDouble();
        System.out.println("Digite o sua altura");
        double altura = sc.nextDouble();
        imc = peso /(altura*altura);
        System.out.println("Seu imc é: " +imc);
        
        if (imc <20){
            System.out.println("Abaixo do peso " );
        }
        else if  (imc <25){
            System.out.println("Peso normal " );
        }
        else if (imc <30){
            System.out.println("Sobrepeso " );
        }
        else if (imc <40){
            System.out.println("Obeso" );
        }
        else {
            System.out.println("Obeso Morbido" );
            
        }
        }
        
        // TODO code application logic here
    }
    

