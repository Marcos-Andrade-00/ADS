package media;

import java.util.Scanner;

public class Media {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("digite o valor de m1");
        int m1 = sc.nextInt();

        System.out.println("digite o valor de m2");
        int m2 = sc.nextInt();

        System.out.println("digite o valor de m3");
        int m3 = sc.nextInt();

        System.out.println("digite o valor de m4");
        int m4 = sc.nextInt();

        int media = (m1 + m2 + m3 + m4) / 4;
        System.out.println("A media dos valores e: " + media);

        if (media >= 5) {
            System.out.println("aprovado");
        }
        
        else if(media >= 4 & media<6 ){
            System.out.println("precisa estudar mais");
        }
        
        else {
            System.out.println("reprovado");
        }
    }

}
