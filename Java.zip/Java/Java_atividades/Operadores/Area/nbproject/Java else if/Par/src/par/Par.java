package par;
import java.util.Scanner;
public class Par {

    public static void main(String[] args) {
        System.out.println("Digite um número inteiro: ");
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        if (num % 2 == 0) {
            System.out.println("O numero: " + num + " e par!");
        }
        else {
            System.out.println("O numero :" + num + " e impar!");
        }
        
    }
    
}
