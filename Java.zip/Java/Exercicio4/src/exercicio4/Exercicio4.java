package exercicio4;
import java.util.Scanner;
public class Exercicio4 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Menu \n ESCOLHA O NÚMERO DO SEU LANCHE \n [1] - Hamburguer \n [2] - Cachorro-quente\n [3] - Batata Frita");
    }
    
}
