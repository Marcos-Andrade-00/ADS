package exercicio2;
import java.util.Scanner;
public class Exercicio2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Infome os numeros da placa do seu carro:  ");
        int placa = sc.nextInt();
        switch (placa){
            case 1,2: System.out.println("O rodizio do seu veículo sera toda segunda-feira ");
            break;
            case 3,4: System.out.println("O rodizio do seu veículo sera toda terça-feira ");
            break;
            case 5,6: System.out.println("\"O rodizio do seu veículo sera toda quarta-feira");
            break;
            case 7,8: System.out.println("O rodizio do seu veículo sera toda quinta-feira ");
            break;
            case 9,0: System.out.println("O rodizio do seu veículo sera toda sexta-feira " );
            break;
            default: System.out.println("Opcão invalida ");
    }
    
}
}
