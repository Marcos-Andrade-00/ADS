package somatorio;

import java.util.Scanner;

public class Somatorio {

    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    double soma = 0;
    int i;
    for(i=1;i<=10;i++){
        System.out.println("Digite um numero inteiro");
        double n1 = sc.nextDouble();
        soma=soma+n1;
        System.out.println("A somatoria é:" + soma);
        }
    
        
    }
  
}    
    
  

    
