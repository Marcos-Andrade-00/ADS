package tabuada;
import java.util.Scanner;
public class Tabuada {
    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    int i ;
    System.out.println("Digite um numero inteiro");
    int numero = sc.nextInt();
    for(i=0; i<=10; i++){
        System.out.println(numero*i);
    }
        
    }
    
}
